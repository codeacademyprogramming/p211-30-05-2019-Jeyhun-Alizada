"use stirict";
const leftLies = Array.from(document.querySelectorAll("ul.leftLies a"));

leftLies.forEach(function(lies) {
  lies.onclick = function(e) {
    const oldActiveRightLi = document.querySelector(".rightLies li.active");
    oldActiveRightLi.classList.remove("active");
    const liNth = this.getAttribute("href");
    document.querySelector(liNth).classList.add("active");
  };
});
